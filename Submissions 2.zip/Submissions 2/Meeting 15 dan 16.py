import tkinter as tk
from datetime import datetime
import os

def get_days_until(birthday_str):
    # Mengubah string tanggal (DD/MM/YY) menjadi objek datetime
    try:
        bday_date = datetime.strptime(birthday_str, "%d/%m/%y")
        today = datetime.now()
        
        # Menghitung selisih hari
        delta = bday_date - today
        return delta.days + 1
    except ValueError:
        return 0

def load_birthdays(filename):
    events = []
    
    # --- BAGIAN PENTING: OTOMATISASI PATH ---
    # Mendapatkan folder tempat script ini disimpan
    folder_script = os.path.dirname(os.path.abspath(__file__))
    # Menggabungkan folder tersebut dengan nama file txt
    path_lengkap = os.path.join(folder_script, filename)
    
    print(f"Mencari file di: {path_lengkap}") # Cek di terminal lokasi aslinya

    if not os.path.exists(path_lengkap):
        print(f"Error: File '{filename}' tidak ditemukan di {folder_script}")
        return []

    try:
        with open(path_lengkap, "r") as file:
            for line in file:
                line = line.strip()
                if "," in line:
                    name, date = line.split(",")
                    days_left = get_days_until(date)
                    events.append((name, days_left))
        # Mengurutkan berdasarkan hari terdekat
        events.sort(key=lambda x: x[1])
    except Exception as e:
        print(f"Terjadi kesalahan saat membaca file: {e}")
    return events

# --- Setup GUI ---
root = tk.Tk()
root.title("Family Birthday Countdown")
root.geometry("600x450")
root.configure(bg="#ffe4c4") 

# Judul Utama
title_label = tk.Label(root, text="My Family Birthday Countdown", 
                       font=("Arial", 18, "bold underline"), 
                       fg="blue", bg="#ffe4c4", pady=20)
title_label.pack()

# Frame untuk daftar ulang tahun
list_frame = tk.Frame(root, bg="#ffe4c4")
list_frame.pack(pady=10, padx=50, fill="both")

# Cukup tulis nama filenya saja, folder akan dicari otomatis oleh fungsi di atas
birthday_list = load_birthdays("birthdays.txt")

if not birthday_list:
    error_lbl = tk.Label(list_frame, text="Data tidak ditemukan atau file tidak terbaca", 
                         fg="red", bg="#ffe4c4", font=("Arial", 12))
    error_lbl.pack()
else:
    for i, (name, days) in enumerate(birthday_list):
        # Warna merah untuk yang paling dekat, hijau untuk sisanya
        text_color = "red" if i == 0 else "darkgreen"
        
        if days == 0:
            display_text = f"Today is {name}'s Birthday! 🎉"
        elif days < 0:
            display_text = f"{name}'s Birthday was {abs(days)} days ago"
        else:
            display_text = f"It is {days} days until {name}'s Birthday"
        
        lbl = tk.Label(list_frame, text=display_text, 
                       font=("Arial", 14, "bold"), 
                       fg=text_color, bg="#ffe4c4", pady=5)
        lbl.pack(anchor="w")

# Menampilkan Tanggal dan Waktu di pojok bawah
now = datetime.now()
time_info = f"Date: {now.strftime('%d/%m/%Y')}\nTime: {now.strftime('%H:%M:%S')}"
footer_label = tk.Label(root, text=time_info, 
                        font=("Arial", 10, "bold"), 
                        fg="darkred", bg="#ffe4c4", justify="right")
footer_label.pack(side="bottom", anchor="e", padx=20, pady=20)

root.mainloop()